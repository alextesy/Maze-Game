package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * Created by אלי on 19/05/2017.
 */
public class Server {
    private int port;
    private int listeningInterval;
    private volatile boolean stop;
    private IServerStrategy serverStrategy;


    public Server(int port, int listeningInterval, IServerStrategy serverStrategy) {
        this.port = port;
        this.listeningInterval = listeningInterval;
        this.serverStrategy = serverStrategy;
        stop = false;
    }
    public void start(){
        new Thread( () -> { runServer();} ).start();

    }
    public void runServer(){
        try {
            ServerSocket server = new ServerSocket(port);
            server.setSoTimeout(listeningInterval);
            while (!stop) {
                try {
                    Socket aClient = server.accept(); // blocking call
                    new Thread(() -> {
                        handleClient(aClient);
                    }).start();
                }
                catch (SocketTimeoutException e)
                {
                }
            }
            server.close();
        }
        catch (IOException e)
        {
        }
    }
    private void handleClient(Socket aClient){
        try{
            serverStrategy.serverStrategy(aClient.getInputStream(), aClient.getOutputStream());
            aClient.getInputStream().close();
            aClient.getOutputStream().close();
        }
        catch(IOException e)
        {
        }


    }
    public void stop() {
        System.out.println("Server has stopped.");
        stop = true;
    }
}
