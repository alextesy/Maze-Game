package Server;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by אלי on 19/05/2017.
 */
public class ServerStrategyGenerateMaze implements IServerStrategy {
    @Override
    public void serverStrategy(InputStream inFromClient, OutputStream outToClient) {
        //has to implement

    }
}
